<section
    <?php echo e($attributes->merge(['class' => "w-full max-w-7xl mx-auto p-4 sm:p-14 border-x border-dashed border-neutral-300 dark:border-white/[9%]"])); ?>

>
    <?php echo e($slot); ?>

</section>
<?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/vendor/laravel/framework/src/Illuminate/Foundation/resources/exceptions/renderer/components/section-container.blade.php ENDPATH**/ ?>