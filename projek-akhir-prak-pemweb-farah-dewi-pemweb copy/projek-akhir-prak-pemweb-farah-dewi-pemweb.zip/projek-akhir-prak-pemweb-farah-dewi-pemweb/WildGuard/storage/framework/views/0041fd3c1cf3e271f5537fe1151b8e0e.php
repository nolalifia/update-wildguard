<?php $__env->startSection('title', $row->nama); ?>

<?php $__env->startSection('content'); ?>
<div class="head">
  <h1><?php echo e($row->nama); ?></h1>
  <a class="btn ghost" href="<?php echo e(route('spesies.index')); ?>">&larr; Kembali</a>
</div>

<div class="card detail">
  <?php if($row->gambar_url): ?>
    <img src="<?php echo e($row->gambar_url); ?>" alt="<?php echo e($row->nama); ?>" referrerpolicy="no-referrer">
  <?php endif; ?>
  <div>
    <p><em><?php echo e($row->nama_latin); ?></em></p>
    <p>
      <span class="badge b-<?php echo e($row->tipe); ?>"><?php echo e($row->tipe); ?></span>
      <span class="badge"><?php echo e($row->status->nama_status); ?> · <?php echo e($row->status->sumber); ?></span>
    </p>
    <dl class="kv">
      <dt>Habitat</dt><dd><?php echo e($row->habitat ?? '-'); ?></dd>
      <dt>Populasi</dt><dd><?php echo e($row->populasi ?? '-'); ?></dd>
      <dt>Ciri khas</dt><dd><?php echo e($row->ciri_khas ?? '-'); ?></dd>
      <dt>Lokasi</dt><dd><?php echo e($row->lokasi->pluck('nama_lokasi')->implode(', ') ?: '-'); ?></dd>
    </dl>
    <h3>Deskripsi</h3>
    <p><?php echo nl2br(e($row->deskripsi ?? '-')); ?></p>
    <?php if($row->fakta): ?>
      <div class="tip"><strong>Tahukah Kamu?</strong><br><?php echo e($row->fakta); ?></div>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/spesies/show.blade.php ENDPATH**/ ?>