<?php $__env->startSection('title', 'Masuk'); ?>

<?php $__env->startSection('content'); ?>
<h1>Masuk</h1>
<p class="auth-sub">Login hanya untuk admin dan pelapor terdaftar. Membaca informasi dan mengirim laporan tidak perlu login.</p>

<form method="post" action="<?php echo e(route('login')); ?>" class="auth-form">
  <?php echo csrf_field(); ?>
  <div class="field">
    <label for="email">Email</label>
    <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" autocomplete="username" required autofocus>
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <div class="field">
    <label for="password">Password</label>
    <input id="password" type="password" name="password" autocomplete="current-password" required>
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <label class="chk"><input type="checkbox" name="ingat" value="1"> Ingat saya</label>
  <button type="submit" class="btn-primary btn-block">Masuk</button>
</form>

<p class="auth-alt">Belum punya akun? <a href="<?php echo e(route('register')); ?>">Daftar sebagai pelapor</a></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/auth/login.blade.php ENDPATH**/ ?>