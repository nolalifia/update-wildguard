<?php $__env->startSection('title', 'Artikel Saya'); ?>

<?php $__env->startSection('content'); ?>
<div class="head">
  <div>
    <h1>Artikel Saya</h1>
    <p class="muted">Usulan artikel tampil di situs setelah disetujui admin. Selama <b>menunggu</b>, masih bisa diubah atau dihapus.</p>
  </div>
  <a class="btn" href="<?php echo e(route('artikel-saya.create')); ?>">+ Usulkan Artikel</a>
</div>

<div class="card tbl">
  <table>
    <thead><tr><th>Judul</th><th>Kategori</th><th>Tanggal</th><th>Status</th><th class="r">Aksi</th></tr></thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <tr>
        <td><strong><?php echo e($r->judul); ?></strong></td>
        <td><span class="badge"><?php echo e($r->kategori->nama_kategori); ?></span></td>
        <td><?php echo e($r->tanggal->format('d/m/Y')); ?></td>
        <td><span class="badge <?php echo e($r->status === 'menunggu' ? 'b-baru' : 'b-selesai'); ?>"><?php echo e($r->status); ?></span></td>
        <td class="r act">
          <?php if($r->status === 'menunggu'): ?>
            <a href="<?php echo e(route('artikel-saya.edit', $r->id_artikel)); ?>">Ubah</a>
            <form method="post" action="<?php echo e(route('artikel-saya.destroy', $r->id_artikel)); ?>" onsubmit="return confirm('Hapus usulan ini?')">
              <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
              <button class="link danger">Hapus</button>
            </form>
          <?php else: ?>
            <span class="muted small">Sudah terbit</span>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <tr><td colspan="5" class="kosong">✍️ Belum ada usulan artikel. Yuk menulis!</td></tr>
    <?php endif; ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/artikel_saya/index.blade.php ENDPATH**/ ?>