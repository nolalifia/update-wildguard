<?php $__env->startSection('title', $row->judul); ?>

<?php $__env->startSection('content'); ?>
<div class="head">
  <h1><?php echo e($row->judul); ?></h1>
  <a class="btn ghost" href="<?php echo e(route('artikel.index')); ?>">&larr; Kembali</a>
</div>
<div class="card detail one">
  <?php if($row->gambar_url): ?>
    <img src="<?php echo e($row->gambar_url); ?>" alt="" referrerpolicy="no-referrer">
  <?php endif; ?>
  <p class="muted">
    <span class="badge"><?php echo e($row->kategori->nama_kategori); ?></span>
    <?php echo e($row->tanggal->format('d F Y')); ?>

  </p>
  <p><?php echo nl2br(e($row->isi)); ?></p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/artikel/show.blade.php ENDPATH**/ ?>