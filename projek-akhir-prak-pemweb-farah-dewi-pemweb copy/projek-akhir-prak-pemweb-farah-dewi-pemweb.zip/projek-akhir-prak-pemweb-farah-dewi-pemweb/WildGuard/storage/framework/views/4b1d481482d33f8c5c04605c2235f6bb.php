<?php $__env->startSection('title', 'Pengguna'); ?>

<?php $__env->startSection('content'); ?>
<div class="head">
  <h1>Pengguna</h1>
  <a class="btn" href="<?php echo e(route('users.create')); ?>">+ Tambah Pengguna</a>
</div>

<div class="card tbl">
  <table>
    <thead><tr><th>Nama</th><th>Email</th><th>Peran</th><th>Laporan</th><th class="r">Aksi</th></tr></thead>
    <tbody>
    <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($r->name); ?> <?php if($r->id === auth()->id()): ?> <span class="muted small">(Anda)</span> <?php endif; ?></td>
        <td><?php echo e($r->email); ?></td>
        <td><span class="badge <?php echo e($r->role === 'admin' ? 'b-fauna' : 'b-flora'); ?>"><?php echo e($r->role); ?></span></td>
        <td><?php echo e($jumlah[$r->id] ?? 0); ?></td>
        <td class="r act">
          <a href="<?php echo e(route('users.edit', $r->id)); ?>">Ubah</a>
          <?php if($r->id !== auth()->id()): ?>
            <form method="post" action="<?php echo e(route('users.destroy', $r->id)); ?>"
                  onsubmit="return confirm('Hapus pengguna ini? Laporannya tetap tersimpan.')">
              <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
              <button class="link danger">Hapus</button>
            </form>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/users/index.blade.php ENDPATH**/ ?>