<?php $__env->startSection('title', 'Spesies'); ?>

<?php $__env->startSection('content'); ?>
<div class="head">
  <h1>Spesies</h1>
  <a class="btn" href="<?php echo e(route('spesies.create')); ?>">+ Tambah Spesies</a>
</div>

<form class="filter" method="get" action="<?php echo e(route('spesies.index')); ?>">
  <input type="search" name="q" value="<?php echo e($q); ?>" placeholder="Cari nama / nama latin...">
  <select name="tipe">
    <option value="">Semua tipe</option>
    <option value="flora" <?php if($tipe === 'flora'): echo 'selected'; endif; ?>>Flora</option>
    <option value="fauna" <?php if($tipe === 'fauna'): echo 'selected'; endif; ?>>Fauna</option>
  </select>
  <button class="btn ghost">Cari</button>
</form>

<div class="card tbl">
<table>
  <thead>
    <tr><th>#</th><th>Nama</th><th>Tipe</th><th>Status</th><th>Lokasi</th><th class="r">Aksi</th></tr>
  </thead>
  <tbody>
  <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
      <td><?php echo e($i + 1); ?></td>
      <td><strong><?php echo e($r->nama); ?></strong><br><em class="muted small"><?php echo e($r->nama_latin); ?></em></td>
      <td><span class="badge b-<?php echo e($r->tipe); ?>"><?php echo e($r->tipe); ?></span></td>
      <td><?php echo e($r->status->nama_status); ?></td>
      <td><?php echo e($r->lokasi->pluck('nama_lokasi')->implode(', ') ?: '-'); ?></td>
      <td class="r act">
        <a href="<?php echo e(route('spesies.show', $r)); ?>">Detail</a>
        <a href="<?php echo e(route('spesies.edit', $r)); ?>">Ubah</a>
        <form method="post" action="<?php echo e(route('spesies.destroy', $r)); ?>" onsubmit="return confirm('Hapus spesies ini?')">
          <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
          <button class="link danger">Hapus</button>
        </form>
      </td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="6" class="kosong">🔍 Hmm, nggak ketemu. Coba kata kunci lain!</td></tr>
  <?php endif; ?>
  </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/spesies/index.blade.php ENDPATH**/ ?>