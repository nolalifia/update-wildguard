<?php $__env->startSection('title', __('Not Found')); ?>
<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('message', __('Not Found')); ?>

<?php echo $__env->make('errors::minimal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/vendor/laravel/framework/src/Illuminate/Foundation/Exceptions/views/404.blade.php ENDPATH**/ ?>