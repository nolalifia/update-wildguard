<?php $__env->startSection('title', 'Kelola Kuis'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">

<div class="kz-bar">
  <div>
    <h1>Kelola Kuis</h1>
    <p>Soal yang aktif akan muncul di kuis halaman utama.</p>
  </div>
  <a class="kz-btn kz-btn-solid" href="<?php echo e(route('kuis-soal.create')); ?>">+ Tambah Soal</a>
</div>

<p class="kz-info">
  <strong><?php echo e($jumlahAktif); ?></strong> soal aktif dari <?php echo e($soalList->count()); ?> soal.
  <?php if($jumlahAktif === 0): ?>
    Belum ada soal aktif, jadi kuis di halaman utama memakai soal acak dari data spesies.
  <?php endif; ?>
</p>

<div class="card tbl kz-scroll">
<table>
  <thead>
    <tr>
      <th>#</th>
      <th>Soal</th>
      <th>Jawaban benar</th>
      <th>Status</th>
      <th class="r">Aksi</th>
    </tr>
  </thead>
  <tbody>
  <?php $__empty_1 = true; $__currentLoopData = $soalList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php $h = strtoupper($s->jawaban_benar); ?>
    <tr>
      <td><?php echo e($i + 1); ?></td>
      <td>
        <div class="kz-soal-cell">
          <?php if($s->gambar): ?>
            <img class="kz-thumb" src="<?php echo e($s->gambar); ?>" alt="" loading="lazy" onerror="this.remove()">
          <?php endif; ?>
          <span><?php echo e($s->pertanyaan); ?></span>
        </div>
      </td>
      <td><span class="kz-jawab" aria-hidden="true"><?php echo e($h); ?></span><?php echo e($s->{'opsi_'.$s->jawaban_benar}); ?></td>
      <td>
        <?php if($s->aktif): ?>
          <span class="badge">Aktif</span>
        <?php else: ?>
          <span class="badge kz-badge-off">Nonaktif</span>
        <?php endif; ?>
      </td>
      <td class="r">
        <div class="kz-aksi">
          <form method="post" action="<?php echo e(route('kuis-soal.toggle', $s)); ?>">
            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
            <button class="kz-btn kz-btn-sm"><?php echo e($s->aktif ? 'Nonaktifkan' : 'Aktifkan'); ?></button>
          </form>
          <a class="kz-btn kz-btn-sm" href="<?php echo e(route('kuis-soal.edit', $s)); ?>">Ubah</a>
          <form method="post" action="<?php echo e(route('kuis-soal.destroy', $s)); ?>" onsubmit="return confirm('Hapus soal ini?')">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button class="kz-btn kz-btn-sm kz-btn-danger">Hapus</button>
          </form>
        </div>
      </td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="5" class="kosong">Belum ada soal. Tambah dulu yuk!</td></tr>
  <?php endif; ?>
  </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/admin/kuis/index.blade.php ENDPATH**/ ?>