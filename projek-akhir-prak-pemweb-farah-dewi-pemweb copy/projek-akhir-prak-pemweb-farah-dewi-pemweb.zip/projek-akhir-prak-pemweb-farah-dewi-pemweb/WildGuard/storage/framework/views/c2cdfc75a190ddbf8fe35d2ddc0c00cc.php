<?php
  $site = $site ?? false;                       // true hanya di halaman utama
  $u = auth()->user();
  $h = fn($id) => $site ? '#'.$id : route('home').'#'.$id;
?>
<a href="#konten" class="skip-link">Lewati ke konten</a>

<header class="navbar">
  <div class="nav-container">
    <a href="<?php echo e($h('beranda')); ?>" class="logo" <?php if($site): ?> data-nav="beranda" <?php endif; ?> aria-label="WildGuard, ke beranda">
      <svg class="logo-mark" viewBox="0 0 32 32" aria-hidden="true">
        <path d="M16 2 4 7v8c0 7.5 5 12.5 12 15 7-2.5 12-7.5 12-15V7L16 2Z" fill="currentColor"/>
        <circle cx="11.5" cy="13" r="2" fill="#fff"/><circle cx="16" cy="10.5" r="2" fill="#fff"/>
        <circle cx="20.5" cy="13" r="2" fill="#fff"/>
        <path d="M16 15c3 0 5.5 2.4 5.5 5 0 1.6-1.4 2.5-2.8 2.2-.9-.2-1.7-.5-2.7-.5s-1.8.3-2.7.5c-1.4.3-2.8-.6-2.8-2.200 0-2.600 2.500-5 5.500-5Z" fill="#fff"/>
      </svg>
      <span>WildGuard</span>
    </a>

    <button type="button" class="nav-toggle" id="nav-toggle" aria-expanded="false" aria-controls="nav-menu" aria-label="Buka menu">
      <span></span><span></span><span></span>
    </button>

    <nav id="nav-menu" aria-label="Navigasi utama">
      <ul class="nav-links">
        <li><a href="<?php echo e($h('beranda')); ?>" <?php if($site): ?> data-nav="beranda" <?php endif; ?>>Beranda</a></li>
        <li><a href="<?php echo e($h('kategori')); ?>" <?php if($site): ?> data-nav="kategori" <?php endif; ?>>Flora &amp; Fauna</a></li>
        <li><a href="<?php echo e($h('edukasi')); ?>" <?php if($site): ?> data-nav="edukasi" <?php endif; ?>>Edukasi</a></li>
        <li><a href="<?php echo e($h('laporan')); ?>" <?php if($site): ?> data-nav="laporan" <?php endif; ?>>Laporkan</a></li>
        <li><a href="<?php echo e($h('tentang')); ?>" <?php if($site): ?> data-nav="tentang" <?php endif; ?>>Tentang Kami</a></li>

        <?php if(auth()->guard()->guest()): ?>
          <li><a href="<?php echo e(route('login')); ?>" class="nav-btn nav-masuk">Masuk</a></li>
        <?php endif; ?>
        <?php if(auth()->guard()->check()): ?>
          <?php if($u->role === 'admin'): ?>
            <li><a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-btn">Kelola</a></li>
          <?php else: ?>
            <li><a href="<?php echo e(route('laporan-saya.index')); ?>" class="nav-btn">Laporan Saya</a></li>
            <li><a href="<?php echo e(route('artikel-saya.index')); ?>" class="nav-btn">Artikel Saya</a></li>
          <?php endif; ?>
          <li>
            <form method="post" action="<?php echo e(route('logout')); ?>" class="nav-logout">
              <?php echo csrf_field(); ?>
              <button type="submit" class="nav-keluar">Keluar</button>
            </form>
          </li>
        <?php endif; ?>
      </ul>
    </nav>
  </div>
</header>
<?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/partials/navbar.blade.php ENDPATH**/ ?>