<?php $__env->startSection('title', $row->exists ? 'Ubah Pengguna' : 'Tambah Pengguna'); ?>

<?php $__env->startSection('content'); ?>
<div class="head"><h1><?php echo e($row->exists ? 'Ubah' : 'Tambah'); ?> Pengguna</h1></div>

<form class="card form narrow" method="post"
      action="<?php echo e($row->exists ? route('users.update', $row->id) : route('users.store')); ?>">
  <?php echo csrf_field(); ?>
  <?php if($row->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
  <div class="field">
    <label>Nama</label>
    <input name="name" value="<?php echo e(old('name', $row->name)); ?>">
    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <div class="field">
    <label>Email</label>
    <input type="email" name="email" value="<?php echo e(old('email', $row->email)); ?>">
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <div class="field">
    <label>Peran</label>
    <select name="role">
      <?php $__currentLoopData = ['user' => 'User (pelapor)', 'admin' => 'Admin']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($v); ?>" <?php if(old('role', $roleDefault) === $v): echo 'selected'; endif; ?>><?php echo e($t); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <div class="field">
    <label>Password <?php if($row->exists): ?> <span class="muted small">(kosongkan kalau tidak diganti)</span> <?php endif; ?></label>
    <input type="password" name="password" autocomplete="new-password">
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <div class="field">
    <label>Ulangi Password</label>
    <input type="password" name="password_confirmation" autocomplete="new-password">
  </div>
  <div class="actions">
    <button class="btn">Simpan</button>
    <a class="btn ghost" href="<?php echo e(route('users.index')); ?>">Batal</a>
  </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/users/form.blade.php ENDPATH**/ ?>