<?php $__env->startSection('title', 'Artikel'); ?>

<?php $__env->startSection('content'); ?>
<div class="head">
  <h1>Artikel</h1>
  <a class="btn" href="<?php echo e(route('artikel.create')); ?>">+ Tambah Artikel</a>
</div>

<form class="filter" method="get" action="<?php echo e(route('artikel.index')); ?>">
  <input type="search" name="q" value="<?php echo e($q); ?>" placeholder="Cari judul artikel...">
  <button class="btn ghost">Cari</button>
</form>

<div class="card tbl">
<table>
  <thead><tr><th>#</th><th>Judul</th><th>Kategori</th><th>Tanggal</th><th>Status</th><th class="r">Aksi</th></tr></thead>
  <tbody>
  <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
      <td><?php echo e($i + 1); ?></td>
      <td><strong><?php echo e($r->judul); ?></strong></td>
      <td><span class="badge"><?php echo e($r->kategori->nama_kategori); ?></span></td>
      <td class="nw"><?php echo e($r->tanggal->format('d M Y')); ?></td>
      <td><span class="badge <?php echo e($r->status === 'menunggu' ? 'b-baru' : 'b-selesai'); ?>"><?php echo e($r->status); ?></span><?php if($r->user && $r->user->role !== 'admin'): ?> <span class="muted small">usulan user</span> <?php endif; ?></td>
      <td class="r act">
        <?php if($r->status === 'menunggu'): ?>
          <form method="post" action="<?php echo e(route('artikel.setujui', $r)); ?>"><?php echo csrf_field(); ?> <button class="link">Setujui</button></form>
        <?php endif; ?>
        <a href="<?php echo e(route('artikel.show', $r)); ?>">Baca</a>
        <a href="<?php echo e(route('artikel.edit', $r)); ?>">Ubah</a>
        <form method="post" action="<?php echo e(route('artikel.destroy', $r)); ?>" onsubmit="return confirm('Hapus artikel ini?')">
          <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
          <button class="link danger">Hapus</button>
        </form>
      </td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="6" class="kosong">🔍 Hmm, nggak ketemu. Coba kata kunci lain!</td></tr>
  <?php endif; ?>
  </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/artikel/index.blade.php ENDPATH**/ ?>