<?php $__env->startSection('title', $cfg['title']); ?>

<?php $__env->startSection('content'); ?>
<div class="head">
  <h1><?php echo e($cfg['title']); ?></h1>
  <a class="btn" href="<?php echo e(route('master.create', $t)); ?>">+ Tambah</a>
</div>

<div class="card tbl">
<table>
  <thead>
    <tr>
      <th>#</th>
      <?php $__currentLoopData = $cfg['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <th><?php echo e($f[0]); ?></th> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <th class="r">Aksi</th>
    </tr>
  </thead>
  <tbody>
  <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php $id = $r->{$cfg['pk']}; ?>
    <tr>
      <td><?php echo e($i + 1); ?></td>
      <?php $__currentLoopData = $cfg['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <td><?php echo e($r->$name ?? '-'); ?></td> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <td class="r act">
        <a href="<?php echo e(route('master.edit', [$t, $id])); ?>">Ubah</a>
        <form method="post" action="<?php echo e(route('master.destroy', [$t, $id])); ?>" onsubmit="return confirm('Hapus data ini?')">
          <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
          <button class="link danger">Hapus</button>
        </form>
      </td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="<?php echo e(count($cfg['fields']) + 2); ?>" class="kosong">🍃 Belum ada data. Tambah dulu yuk!</td></tr>
  <?php endif; ?>
  </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/master/index.blade.php ENDPATH**/ ?>