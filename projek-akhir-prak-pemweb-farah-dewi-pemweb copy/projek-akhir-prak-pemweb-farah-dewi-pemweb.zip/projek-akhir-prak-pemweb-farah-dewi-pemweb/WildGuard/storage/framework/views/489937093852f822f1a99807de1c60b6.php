<?php $__env->startSection('title', $cfg['title']); ?>

<?php $__env->startSection('content'); ?>
<?php $edit = $row !== null; ?>
<div class="head"><h1><?php echo e($edit ? 'Ubah' : 'Tambah'); ?> <?php echo e($cfg['title']); ?></h1></div>

<form class="card form narrow" method="post"
      action="<?php echo e($edit ? route('master.update', [$t, $row->{$cfg['pk']}]) : route('master.store', $t)); ?>">
  <?php echo csrf_field(); ?>
  <?php if($edit): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

  <?php $__currentLoopData = $cfg['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="field">
      <label><?php echo e($f[0]); ?></label>
      <?php if($f[1] === 'select'): ?>
        <select name="<?php echo e($name); ?>">
          <?php $__currentLoopData = $f[3]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php if(old($name, $row->$name ?? '') === $opt): echo 'selected'; endif; ?>><?php echo e($opt); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      <?php else: ?>
        <input name="<?php echo e($name); ?>" value="<?php echo e(old($name, $row->$name ?? '')); ?>">
      <?php endif; ?>
      <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <div class="actions">
    <button class="btn">Simpan</button>
    <a class="btn ghost" href="<?php echo e(route('master.index', $t)); ?>">Batal</a>
  </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/master/form.blade.php ENDPATH**/ ?>