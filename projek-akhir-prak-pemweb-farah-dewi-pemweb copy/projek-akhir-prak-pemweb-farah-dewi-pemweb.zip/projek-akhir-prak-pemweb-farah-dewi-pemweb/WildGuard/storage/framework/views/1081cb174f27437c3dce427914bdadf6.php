<?php $__env->startSection('title', 'Ubah Laporan'); ?>

<?php $__env->startSection('content'); ?>
<div class="head"><h1>Ubah Laporan</h1></div>

<form class="card form" method="post" enctype="multipart/form-data" action="<?php echo e(route('laporan-saya.update', $row->id_laporan)); ?>">
  <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
  <input type="hidden" name="kembali" value="<?php echo e(old('kembali', $kembali ?? '')); ?>">
  <div class="g2">
    <div class="field">
      <label>Jenis Temuan</label>
      <select name="id_jenis">
        <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($j->id_jenis); ?>" <?php if((int) old('id_jenis', $row->id_jenis) === (int) $j->id_jenis): echo 'selected'; endif; ?>><?php echo e($j->nama_jenis); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <?php $__errorArgs = ['id_jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="field">
      <label>Tanggal Kejadian</label>
      <input type="date" name="tanggal_kejadian" max="<?php echo e(now()->format('Y-m-d')); ?>"
             value="<?php echo e(old('tanggal_kejadian', $row->tanggal_kejadian->format('Y-m-d'))); ?>">
      <?php $__errorArgs = ['tanggal_kejadian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
  </div>
  <div class="field">
    <label>Lokasi Kejadian</label>
    <input name="lokasi_kejadian" value="<?php echo e(old('lokasi_kejadian', $row->lokasi_kejadian)); ?>">
    <?php $__errorArgs = ['lokasi_kejadian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <div class="field">
    <label>Deskripsi</label>
    <textarea name="deskripsi" rows="5"><?php echo e(old('deskripsi', $row->deskripsi)); ?></textarea>
    <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <div class="field">
    <label>Lampiran <span class="muted small">(kosongkan kalau tidak diganti; jpg/png/webp/pdf, maks 5 MB)</span></label>
    <?php if($row->lampiran): ?>
      <p class="small">Saat ini: <a href="<?php echo e(asset($row->lampiran)); ?>" target="_blank">lihat lampiran</a></p>
    <?php endif; ?>
    <input type="file" name="lampiran" accept="image/*,.pdf">
    <?php $__errorArgs = ['lampiran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <div class="actions">
    <button class="btn">Simpan</button>
    <a class="btn ghost" href="<?php echo e(\App\Support\Kembali::url(old('kembali', $kembali ?? ''), route('laporan-saya.index'))); ?>">Batal</a>
  </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/laporan_saya/edit.blade.php ENDPATH**/ ?>