<?php $__env->startSection('title', $row->exists ? 'Ubah Artikel' : 'Tambah Artikel'); ?>

<?php $__env->startSection('content'); ?>
<div class="head"><h1><?php echo e($row->exists ? 'Ubah' : 'Tambah'); ?> Artikel</h1></div>

<form class="card form" method="post"
      action="<?php echo e($row->exists ? route('artikel.update', $row) : route('artikel.store')); ?>">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="kembali" value="<?php echo e(old('kembali', $kembali ?? '')); ?>">
  <?php if($row->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

  <div class="field">
    <label>Judul</label>
    <input name="judul" value="<?php echo e(old('judul', $row->judul)); ?>">
    <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <div class="g2">
    <div class="field">
      <label>Kategori</label>
      <select name="id_kategori">
        <option value="">-- pilih --</option>
        <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($k->id_kategori); ?>" <?php if((int) old('id_kategori', $row->id_kategori) === (int) $k->id_kategori): echo 'selected'; endif; ?>>
            <?php echo e($k->nama_kategori); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <?php $__errorArgs = ['id_kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="field">
      <label>Tanggal</label>
      <input type="date" name="tanggal" value="<?php echo e(old('tanggal', $row->tanggal?->format('Y-m-d'))); ?>">
      <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
  </div>
  <div class="field">
    <label>Isi Artikel <span class="muted small">(pisahkan paragraf dengan baris kosong)</span></label>
    <textarea name="isi" rows="8"><?php echo e(old('isi', $row->isi)); ?></textarea>
    <?php $__errorArgs = ['isi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <div class="field">
    <label>URL Gambar</label>
    <input name="gambar_url" value="<?php echo e(old('gambar_url', $row->gambar_url)); ?>">
    <?php $__errorArgs = ['gambar_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <div class="actions">
    <button class="btn">Simpan</button>
    <a class="btn ghost" href="<?php echo e(\App\Support\Kembali::url(old('kembali', $kembali ?? ''), route('artikel.index'))); ?>">Batal</a>
  </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/artikel/form.blade.php ENDPATH**/ ?>