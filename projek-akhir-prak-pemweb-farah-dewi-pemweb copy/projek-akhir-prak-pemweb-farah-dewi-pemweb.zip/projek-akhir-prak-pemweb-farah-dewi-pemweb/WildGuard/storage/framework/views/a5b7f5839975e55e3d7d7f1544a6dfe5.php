<?php $__env->startSection('title', $row->exists ? 'Ubah Spesies' : 'Tambah Spesies'); ?>

<?php $__env->startSection('content'); ?>
<div class="head"><h1><?php echo e($row->exists ? 'Ubah' : 'Tambah'); ?> Spesies</h1></div>

<form class="card form" method="post"
      action="<?php echo e($row->exists ? route('spesies.update', $row) : route('spesies.store')); ?>">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="kembali" value="<?php echo e(old('kembali', $kembali ?? '')); ?>">
  <?php if($row->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

  <div class="g2">
    <div class="field">
      <label>Nama</label>
      <input name="nama" value="<?php echo e(old('nama', $row->nama)); ?>">
      <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="field">
      <label>Nama Latin</label>
      <input name="nama_latin" value="<?php echo e(old('nama_latin', $row->nama_latin)); ?>">
      <?php $__errorArgs = ['nama_latin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="field">
      <label>Tipe</label>
      <select name="tipe">
        <?php $__currentLoopData = ['flora', 'fauna']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($t); ?>" <?php if(old('tipe', $row->tipe) === $t): echo 'selected'; endif; ?>><?php echo e(ucfirst($t)); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <?php $__errorArgs = ['tipe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="field">
      <label>Status Perlindungan</label>
      <select name="id_status">
        <option value="">-- pilih --</option>
        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($s->id_status); ?>" <?php if((int) old('id_status', $row->id_status) === (int) $s->id_status): echo 'selected'; endif; ?>>
            <?php echo e($s->nama_status); ?> (<?php echo e($s->sumber); ?>)
          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <?php $__errorArgs = ['id_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="field">
      <label>Habitat</label>
      <input name="habitat" value="<?php echo e(old('habitat', $row->habitat)); ?>">
      <?php $__errorArgs = ['habitat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="field">
      <label>Populasi</label>
      <input name="populasi" value="<?php echo e(old('populasi', $row->populasi)); ?>" placeholder="mis. Sekitar 3.000 ekor">
      <?php $__errorArgs = ['populasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
  </div>

  <div class="field">
    <label>Lokasi Sebaran <span class="muted small">(boleh lebih dari satu)</span></label>
    <div class="checks">
      <?php $__currentLoopData = $lokasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label class="chk">
          <input type="checkbox" name="lokasi[]" value="<?php echo e($l->id_lokasi); ?>"
                 <?php if(in_array((int) $l->id_lokasi, array_map('intval', $selected), true)): echo 'checked'; endif; ?>>
          <?php echo e($l->nama_lokasi); ?>

        </label>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>

  <div class="g2">
    <div class="field">
      <label>Ciri Khas <span class="muted small">(untuk flora)</span></label>
      <input name="ciri_khas" value="<?php echo e(old('ciri_khas', $row->ciri_khas)); ?>">
      <?php $__errorArgs = ['ciri_khas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="field">
      <label>Ringkasan <span class="muted small">(teks singkat di kartu)</span></label>
      <input name="ringkasan" value="<?php echo e(old('ringkasan', $row->ringkasan)); ?>">
      <?php $__errorArgs = ['ringkasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
  </div>

  <div class="field">
    <label>Deskripsi</label>
    <textarea name="deskripsi" rows="4"><?php echo e(old('deskripsi', $row->deskripsi)); ?></textarea>
  </div>
  <div class="field">
    <label>Tahukah Kamu?</label>
    <textarea name="fakta" rows="2"><?php echo e(old('fakta', $row->fakta)); ?></textarea>
  </div>
  <div class="field">
    <label>URL Gambar</label>
    <input name="gambar_url" value="<?php echo e(old('gambar_url', $row->gambar_url)); ?>">
    <?php $__errorArgs = ['gambar_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

  <div class="actions">
    <button class="btn">Simpan</button>
    <a class="btn ghost" href="<?php echo e(\App\Support\Kembali::url(old('kembali', $kembali ?? ''), route('spesies.index'))); ?>">Batal</a>
  </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/spesies/form.blade.php ENDPATH**/ ?>