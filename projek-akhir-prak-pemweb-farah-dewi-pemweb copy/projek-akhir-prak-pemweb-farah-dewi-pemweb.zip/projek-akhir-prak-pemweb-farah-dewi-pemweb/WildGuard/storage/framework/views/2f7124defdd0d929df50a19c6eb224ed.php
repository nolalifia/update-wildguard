<?php $__env->startSection('title', 'Laporan'); ?>

<?php $__env->startSection('content'); ?>
<div class="head">
  <h1>Laporan Temuan</h1>
</div>

<form class="filter" method="get" action="<?php echo e(route('laporan.index')); ?>">
  <select name="status" onchange="this.form.submit()">
    <option value="">Semua status</option>
    <?php $__currentLoopData = ['baru', 'diproses', 'selesai']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($s); ?>" <?php if($status === $s): echo 'selected'; endif; ?>><?php echo e(ucfirst($s)); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
</form>

<div class="card tbl">
<table>
  <thead>
    <tr><th>#</th><th>Tanggal</th><th>Lokasi</th><th>Jenis</th><th>Spesies</th><th>Status</th><th class="r">Aksi</th></tr>
  </thead>
  <tbody>
  <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
      <td><?php echo e($i + 1); ?></td>
      <td class="nw"><?php echo e($r->tanggal_kejadian->format('d M Y')); ?></td>
      <td><?php echo e($r->lokasi_kejadian); ?><br><span class="muted small"><?php echo e(\Illuminate\Support\Str::limit($r->deskripsi, 70)); ?></span>
        <?php if($r->lampiran): ?> <br><a class="small" href="<?php echo e(asset($r->lampiran)); ?>" target="_blank">Lampiran</a> <?php endif; ?></td>
      <td><?php echo e($r->jenis->nama_jenis); ?></td>
      <td><?php echo e($r->spesies->nama ?? '-'); ?></td>
      <td><span class="badge b-<?php echo e($r->status_laporan); ?>"><?php echo e($r->status_laporan); ?></span></td>
      <td class="r act">
        <a href="<?php echo e(route('laporan.edit', $r)); ?>">Ubah status</a>
        <form method="post" action="<?php echo e(route('laporan.destroy', $r)); ?>" style="display:inline"
              onsubmit="return confirm('Hapus laporan ini secara permanen? Tindakan ini tidak bisa dibatalkan.')">
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>
          <button type="submit" style="background:none;border:0;padding:0 0 0 12px;font:inherit;color:#B8336A;font-weight:700;cursor:pointer">Hapus</button>
        </form>
      </td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="7" class="muted center">Belum ada laporan.</td></tr>
  <?php endif; ?>
  </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/laporan/index.blade.php ENDPATH**/ ?>