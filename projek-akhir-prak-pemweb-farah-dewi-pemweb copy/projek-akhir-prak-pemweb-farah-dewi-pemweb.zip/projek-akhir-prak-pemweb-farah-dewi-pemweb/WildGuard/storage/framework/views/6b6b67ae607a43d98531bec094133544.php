<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $__env->yieldContent('title', 'WildGuard'); ?> - WildGuard</title>
  <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@600;700;800&family=Quicksand:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('css/wildguard.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/crud.css')); ?>">
</head>
<body class="halaman-dalam">
  <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <main class="auth-wrap">
    <div class="auth-card">
      <?php if(session('ok')): ?> <div class="alert ok"><?php echo e(session('ok')); ?></div> <?php endif; ?>
      <?php if(session('err')): ?> <div class="alert err"><?php echo e(session('err')); ?></div> <?php endif; ?>
      <?php echo $__env->yieldContent('content'); ?>
    </div>
  </main>

  <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <script src="<?php echo e(asset('js/nav.js')); ?>"></script>
</body>
</html><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/layouts/auth.blade.php ENDPATH**/ ?>