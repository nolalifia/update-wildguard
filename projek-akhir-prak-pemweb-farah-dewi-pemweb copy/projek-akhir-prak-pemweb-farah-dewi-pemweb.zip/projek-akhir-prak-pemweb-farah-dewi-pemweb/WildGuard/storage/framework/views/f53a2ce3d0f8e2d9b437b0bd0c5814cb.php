<?php $__env->startSection('title', 'Daftar'); ?>

<?php $__env->startSection('content'); ?>
<h1>Daftar Akun Pelapor</h1>
<p class="auth-sub">Dengan akun, Anda bisa melihat, mengubah, dan menghapus laporan yang pernah Anda kirim.</p>

<form method="post" action="<?php echo e(route('register')); ?>" class="auth-form">
  <?php echo csrf_field(); ?>
  <div class="field">
    <label for="name">Nama</label>
    <input id="name" name="name" value="<?php echo e(old('name')); ?>" autocomplete="name" minlength="3" maxlength="100" required autofocus>
    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <div class="field">
    <label for="email">Email</label>
    <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" autocomplete="username" required>
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <div class="field">
    <label for="password">Password</label>
    <input id="password" type="password" name="password" autocomplete="new-password" maxlength="72" required>
    <?php $__currentLoopData = $errors->get('password'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <p class="error"><?php echo e($pesan); ?></p> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <ul class="pw-cek" id="pwCek" aria-live="polite">
      <li data-r="len">Minimal 8 karakter</li>
      <li data-r="up">Ada huruf besar (A-Z)</li>
      <li data-r="lo">Ada huruf kecil (a-z)</li>
      <li data-r="num">Ada angka (0-9)</li>
      <li data-r="sym">Ada simbol (! @ # $ %)</li>
      <li data-r="sp">Tanpa spasi</li>
      <li data-r="idn">Tidak sama dengan nama atau email</li>
    </ul>
  </div>
  <div class="field">
    <label for="password_confirmation">Ulangi password</label>
    <input id="password_confirmation" type="password" name="password_confirmation" autocomplete="new-password" maxlength="72" required>
    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <p class="error" id="pwBeda" hidden>Konfirmasi password belum cocok.</p>
  </div>
  <button type="submit" class="btn-primary btn-block">Daftar</button>
</form>

<script>
(function () {
  var pw = document.getElementById('password'), pc = document.getElementById('password_confirmation');
  var nm = document.getElementById('name'), em = document.getElementById('email');
  var li = {}; document.querySelectorAll('#pwCek li').forEach(function (x) { li[x.dataset.r] = x; });
  var beda = document.getElementById('pwBeda');
  function set(k, ok) { li[k].classList.toggle('ok', ok); }
  function cek() {
    var v = pw.value, l = v.toLowerCase();
    set('len', v.length >= 8);
    set('up', /[A-Z]/.test(v)); set('lo', /[a-z]/.test(v)); set('num', /\d/.test(v));
    set('sym', /[^A-Za-z0-9]/.test(v)); set('sp', v.length > 0 && !/\s/.test(v));
    var e = em.value.toLowerCase(), eb = e.split('@')[0];
    set('idn', v.length > 0 && l !== nm.value.trim().toLowerCase() && l !== e && l !== eb);
    beda.hidden = !pc.value || pc.value === v;
  }
  [pw, pc, nm, em].forEach(function (x) { x.addEventListener('input', cek); }); cek();
})();
</script>

<p class="auth-alt">Sudah punya akun? <a href="<?php echo e(route('login')); ?>">Masuk</a></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/auth/register.blade.php ENDPATH**/ ?>