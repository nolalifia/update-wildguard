<?php $__env->startSection('title', 'Ubah Status Laporan'); ?>

<?php $__env->startSection('content'); ?>
<div class="head"><h1>Ubah Status Laporan</h1></div>

<form class="card form" method="post" action="<?php echo e(route('laporan.update', $row)); ?>">
  <?php echo csrf_field(); ?>
  <?php echo method_field('PUT'); ?>
  <input type="hidden" name="kembali" value="<?php echo e(old('kembali', $kembali ?? '')); ?>">

  <p class="muted small">Isi laporan hanya bisa dibaca. Admin hanya dapat mengubah status penanganannya.</p>

  <div class="g2">
    <div class="field">
      <label>Jenis Temuan</label>
      <input value="<?php echo e($row->jenis->nama_jenis ?? '-'); ?>" readonly>
    </div>
    <div class="field">
      <label>Spesies terkait</label>
      <input value="<?php echo e($row->spesies->nama ?? 'Tidak diketahui'); ?>" readonly>
    </div>
    <div class="field">
      <label>Lokasi Kejadian</label>
      <input value="<?php echo e($row->lokasi_kejadian); ?>" readonly>
    </div>
    <div class="field">
      <label>Tanggal Kejadian</label>
      <input value="<?php echo e($row->tanggal_kejadian?->format('d/m/Y')); ?>" readonly>
    </div>
  </div>
  <div class="field">
    <label>Deskripsi</label>
    <textarea rows="5" readonly><?php echo e($row->deskripsi); ?></textarea>
  </div>
  <?php if($row->lampiran): ?>
    <p class="small"><a href="<?php echo e(asset($row->lampiran)); ?>" target="_blank" rel="noopener">Lihat lampiran</a></p>
  <?php endif; ?>

  <div class="field">
    <label for="status_laporan">Status Laporan</label>
    <select id="status_laporan" name="status_laporan">
      <?php $__currentLoopData = ['baru', 'diproses', 'selesai']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($s); ?>" <?php if(old('status_laporan', $row->status_laporan ?? 'baru') === $s): echo 'selected'; endif; ?>><?php echo e(ucfirst($s)); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = ['status_laporan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <div class="actions">
    <button class="btn">Simpan status</button>
    <a class="btn ghost" href="<?php echo e(\App\Support\Kembali::url(old('kembali', $kembali ?? ''), route('laporan.index'))); ?>">Batal</a>
  </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/laporan/form.blade.php ENDPATH**/ ?>