<?php
  $site = $site ?? false;
  $h = fn($id) => $site ? '#'.$id : route('home').'#'.$id;
?>
<footer class="footer">
  <div class="footer-content">
    <div class="footer-brand">
      <h3>WildGuard</h3>
      <p>Bersama menjaga kelestarian flora dan fauna, di darat maupun di laut.</p>
    </div>

    <nav class="footer-nav" aria-label="Navigasi footer">
      <a href="<?php echo e($h('kategori')); ?>" <?php if($site): ?> data-nav="kategori" <?php endif; ?>>Flora &amp; Fauna</a>
      <a href="<?php echo e($h('edukasi')); ?>" <?php if($site): ?> data-nav="edukasi" <?php endif; ?>>Edukasi</a>
      <a href="<?php echo e($h('laporan')); ?>" <?php if($site): ?> data-nav="laporan" <?php endif; ?>>Laporkan</a>
      <a href="<?php echo e($h('tentang')); ?>" <?php if($site): ?> data-nav="tentang" <?php endif; ?>>Tentang Kami</a>
    </nav>
  </div>
  <p class="footer-copy">&copy; 2026 WildGuard. Untuk kelestarian alam Indonesia.</p>
</footer>
<?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/partials/footer.blade.php ENDPATH**/ ?>