<?php $__env->startSection('title', $soal->exists ? 'Ubah Soal Kuis' : 'Tambah Soal Kuis'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">

<?php
  // setelah validasi gagal, centang "aktif" mengikuti isian sebelumnya
  $aktif = session()->hasOldInput() ? (bool) old('aktif') : (bool) $soal->aktif;
  $benar = old('jawaban_benar', $soal->jawaban_benar ?: 'a');
?>

<div class="kz-bar">
  <div>
    <h1><?php echo e($soal->exists ? 'Ubah' : 'Tambah'); ?> Soal Kuis</h1>
    <p>Isi minimal dua pilihan, lalu tandai satu jawaban yang benar.</p>
  </div>
</div>

<?php if($errors->any()): ?>
  <div class="kz-alert kz-alert-err" role="alert">
    Soal belum bisa disimpan:
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <li><?php echo e($e); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>

<div class="card kz-form-card">
<form class="kz-form" method="post"
      action="<?php echo e($soal->exists ? route('kuis-soal.update', $soal) : route('kuis-soal.store')); ?>">
  <?php echo csrf_field(); ?>
  <?php if($soal->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

  <div class="kz-field">
    <label class="kz-label" for="pertanyaan">Pertanyaan</label>
    <textarea id="pertanyaan" name="pertanyaan" rows="3" maxlength="300" required><?php echo e(old('pertanyaan', $soal->pertanyaan)); ?></textarea>
  </div>

  <fieldset class="kz-fieldset">
    <legend class="kz-label">Pilihan jawaban</legend>
    <p class="kz-hint">Klik huruf di kiri untuk menandai jawaban yang benar. Pilihan C dan D boleh dikosongkan.</p>
    <div class="kz-opsi-grid">
      <?php $__currentLoopData = ['a', 'b', 'c', 'd']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="kz-opsi">
          <label class="kz-radio" title="Jadikan <?php echo e(strtoupper($k)); ?> jawaban benar">
            <input type="radio" name="jawaban_benar" value="<?php echo e($k); ?>" <?php if($benar === $k): echo 'checked'; endif; ?>>
            <span><?php echo e(strtoupper($k)); ?></span>
          </label>
          <input type="text" name="opsi_<?php echo e($k); ?>" maxlength="200"
                 value="<?php echo e(old('opsi_'.$k, $soal->{'opsi_'.$k})); ?>"
                 placeholder="Pilihan <?php echo e(strtoupper($k)); ?><?php echo e(in_array($k, ['a', 'b']) ? '' : ' (opsional)'); ?>"
                 aria-label="Pilihan <?php echo e(strtoupper($k)); ?>" <?php if(in_array($k, ['a', 'b'])): echo 'required'; endif; ?>>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </fieldset>

  <div class="kz-field">
    <label class="kz-label" for="penjelasan">Penjelasan <span class="kz-opsional">(opsional)</span></label>
    <textarea id="penjelasan" name="penjelasan" rows="3" maxlength="1000"><?php echo e(old('penjelasan', $soal->penjelasan)); ?></textarea>
    <p class="kz-hint">Ditampilkan setelah pemain menjawab.</p>
  </div>

  <div class="kz-field">
    <label class="kz-label" for="gambar">URL gambar <span class="kz-opsional">(opsional)</span></label>
    <input type="url" id="gambar" name="gambar" maxlength="255" placeholder="https://..."
           value="<?php echo e(old('gambar', $soal->gambar)); ?>">
  </div>

  <label class="kz-cek">
    <input type="checkbox" name="aktif" value="1" <?php if($aktif): echo 'checked'; endif; ?>>
    Aktif (tampil di kuis)
  </label>

  <div class="kz-form-aksi">
    <button class="kz-btn kz-btn-solid">Simpan</button>
    <a class="kz-btn" href="<?php echo e(route('kuis-soal.index')); ?>">Batal</a>
  </div>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/admin/kuis/form.blade.php ENDPATH**/ ?>