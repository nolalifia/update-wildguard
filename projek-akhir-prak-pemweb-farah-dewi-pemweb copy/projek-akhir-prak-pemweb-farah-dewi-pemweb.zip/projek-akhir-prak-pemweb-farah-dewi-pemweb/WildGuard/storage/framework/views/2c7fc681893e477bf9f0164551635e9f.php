<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<h1>Dashboard</h1>
<p class="muted">Ringkasan data WildGuard yang tersimpan di database.</p>

<div class="stats">
  <div class="stat"><span><?php echo e($jFlora); ?></span>Flora</div>
  <div class="stat"><span><?php echo e($jFauna); ?></span>Fauna</div>
  <div class="stat"><span><?php echo e($jArtikel); ?></span>Artikel</div>
  <div class="stat"><span><?php echo e($jLaporan); ?></span>Laporan</div>
</div>

<div class="cols">
  <section class="card">
    <h2>Laporan per Jenis Temuan</h2>
    <table>
      <thead><tr><th>Jenis</th><th class="r">Jumlah</th></tr></thead>
      <tbody>
      <?php $__currentLoopData = $perJenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr><td><?php echo e($r->nama_jenis); ?></td><td class="r"><?php echo e($r->laporan_count); ?></td></tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <p class="muted small">Dihasilkan lewat relasi jenis_temuan → laporan (withCount / GROUP BY).</p>
  </section>

  <section class="card">
    <h2>Laporan Terbaru</h2>
    <?php if($terbaru->isEmpty()): ?>
      <p class="muted">Belum ada laporan.</p>
    <?php else: ?>
      <table>
        <thead><tr><th>Lokasi</th><th>Jenis</th><th>Status</th></tr></thead>
        <tbody>
        <?php $__currentLoopData = $terbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($r->lokasi_kejadian); ?></td>
            <td><?php echo e($r->jenis->nama_jenis); ?></td>
            <td><span class="badge b-<?php echo e($r->status_laporan); ?>"><?php echo e($r->status_laporan); ?></span></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    <?php endif; ?>
  </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/home/index.blade.php ENDPATH**/ ?>