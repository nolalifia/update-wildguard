<?php $__env->startSection('title', 'Laporan Saya'); ?>

<?php $__env->startSection('content'); ?>
<div class="head">
  <div>
    <h1>Laporan Saya</h1>
    <p class="muted">Halo, <?php echo e(auth()->user()->name); ?>. Laporan bisa diubah atau dihapus selama statusnya masih <b>baru</b>.</p>
  </div>
  <a class="btn" href="<?php echo e(route('home')); ?>#laporan">+ Kirim Laporan Baru</a>
</div>

<div class="card tbl">
  <table>
    <thead><tr><th>Tanggal Kejadian</th><th>Jenis</th><th>Lokasi</th><th>Status</th><th class="r">Aksi</th></tr></thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <tr>
        <td class="nw"><?php echo e($r->tanggal_kejadian->format('d/m/Y')); ?></td>
        <td><?php echo e($r->jenis->nama_jenis); ?></td>
        <td><?php echo e($r->lokasi_kejadian); ?><br><span class="muted small"><?php echo e(\Illuminate\Support\Str::limit($r->deskripsi, 80)); ?></span></td>
        <td><span class="badge b-<?php echo e($r->status_laporan); ?>"><?php echo e($r->status_laporan); ?></span></td>
        <td class="r act">
          <?php if($r->status_laporan === 'baru'): ?>
            <a href="<?php echo e(route('laporan-saya.edit', $r->id_laporan)); ?>">Ubah</a>
            <form method="post" action="<?php echo e(route('laporan-saya.destroy', $r->id_laporan)); ?>"
                  onsubmit="return confirm('Hapus laporan ini?')">
              <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
              <button class="link danger">Hapus</button>
            </form>
          <?php else: ?>
            <span class="muted small">Sudah ditangani</span>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <tr><td colspan="5" class="kosong">Belum ada laporan. Kirim lewat form "Laporkan" saat Anda masuk, maka laporan otomatis tercatat di sini.</td></tr>
    <?php endif; ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nao/Documents/unpad/SEMESTER 3/SEMESTER 3 VSCODE/Tugas Pemrograman Web/PRAKTIKUM/projek-akhir-prak-pemweb-farah-dewi-pemweb/WildGuard/resources/views/laporan_saya/index.blade.php ENDPATH**/ ?>